package com.example.kalyan.timetable;

/**
 * Created by AJAY KUMAR on 10/29/2017.
 */

public class User {
    String username;
    String polls;
    String flag;
    public User (){

    }
    public User (String username ,String polls,String flag){
        this.username=username;
        this.polls=polls;
        this.flag=flag;
    }
}
