Timetable
=========

An android application that helps to organize your events. Support all android versions starting from platform 2.1. On every android version application has [Holo](http://developer.android.com/design/style/themes.html) theme.

##Installation

To install source code simply clone this repository to your local machine and import it as a project to your eclipse workspace. You also need to install [HoloEverywhere](https://github.com/Prototik/HoloEverywhere) library.
